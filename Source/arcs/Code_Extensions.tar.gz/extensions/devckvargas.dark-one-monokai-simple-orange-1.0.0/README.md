# Dark+ One Monokai: Simple Orange

[Dark+ One Monokai](https://github.com/Geobert/dark-plus-one-monokai) syntax w/ [Simple Orange](https://themes.vscode.one/theme/alexsuriano/oXnK6FLi) editor colors
